from utils.constants import (
    EXACT_SCORE_POINTS,
    WINNER_DIFF_POINTS,
    WINNER_ONLY_POINTS,
    QUALIFIED_TEAM_POINTS,
    TOURNAMENT_CHAMPION,
    CHAMPION_POINTS
)


def get_match_result(
    home_score: int,
    away_score: int
):

    if home_score > away_score:
        return "HOME"

    if away_score > home_score:
        return "AWAY"

    return "DRAW"


def calculate_prediction_score(
    prediction,
    match
):

    score = 0

    predicted_result = get_match_result(
        prediction.pred_home,
        prediction.pred_away
    )

    actual_result = get_match_result(
        match.home_score,
        match.away_score
    )

    predicted_diff = (
        prediction.pred_home
        - prediction.pred_away
    )

    actual_diff = (
        match.home_score
        - match.away_score
    )

    # ==========================
    # Match Score
    # ==========================

    if (
        prediction.pred_home
        == match.home_score
        and
        prediction.pred_away
        == match.away_score
    ):

        score += EXACT_SCORE_POINTS

    elif (
        predicted_result == actual_result
        and
        predicted_diff == actual_diff
    ):

        score += WINNER_DIFF_POINTS

    elif predicted_result == actual_result:

        score += WINNER_ONLY_POINTS

    # ==========================
    # Qualified Team
    # ==========================

    if match.qualified_team is not None:

        if (
            actual_result == "DRAW"
            and
            prediction.pred_qualified_team is not None
            and
            prediction.pred_qualified_team == match.qualified_team
        ):

            score += QUALIFIED_TEAM_POINTS

        elif (
            actual_result != "DRAW"
            and
            predicted_result == actual_result
            and
            prediction.pred_qualified_team == match.qualified_team
        ):

            score += QUALIFIED_TEAM_POINTS

    return score


def calculate_user_score(
    user
):

    total_score = 0

    for prediction in user.predictions:

        match = prediction.match

        if not match.result_entered:
            continue

        total_score += (
            calculate_prediction_score(
                prediction,
                match
            )
        )

    
    if user.tournament_prediction:

        total_score += (
            calculate_tournament_score(
                user.tournament_prediction
            )
        )

    return total_score

def calculate_tournament_score(
    prediction
):
    score = 0
    if (
        TOURNAMENT_CHAMPION is None
    ):

        return 0
    if (
        prediction.champion
        and
        prediction.champion
        ==
        TOURNAMENT_CHAMPION
    ):
        score += CHAMPION_POINTS
    return score
